(() => {
  // Define constants
  const API_KEY = "AIzaSyD0sn2tQujelt19MXzGGQDSSMZicGjObdg";
  const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

  // Notification function
  if (!window.showNotification) {
    window.showNotification = (text) => {
      document.body.style.position = "relative";
      const notification = document.createElement("div");
      notification.innerText = text;
      notification.style.position = "fixed";
      notification.style.bottom = "12px";
      notification.style.right = "12px";
      notification.style.backgroundColor = "rgba(0, 0, 0, 0.05)";
      notification.style.padding = "12px";
      notification.style.color = "rgba(0, 0, 0, 0.5)";
      notification.style.borderRadius = "12px";
      notification.style.maxWidth = "250px";
      notification.style.maxHeight = "150px";
      notification.style.overflowY = "scroll";

      notification.onclick = () => document.body.removeChild(notification);
      document.body.appendChild(notification);

      const progress = document.createElement("div");
      progress.style.position = "absolute";
      progress.style.bottom = "0";
      progress.style.left = "0";
      progress.style.width = "0%";
      progress.style.height = "5px";
      progress.style.backgroundColor = "black";
      progress.style.opacity = "0.1";
      progress.style.transition = "width 3s linear";
      notification.appendChild(progress);

      setTimeout(() => progress.style.width = "100%", 10);
      setTimeout(() => document.body.removeChild(notification), 1000);
    };
  }

  // Listener management function (only register, no unregister)
  if (!window.registerListeners) {
    window.registerListeners = () => {
      document.addEventListener("mouseover", window.mouseOver);
      document.addEventListener("mouseout", window.mouseOut);
      document.addEventListener("click", window.mouseClick);
    };
  }

  // Event handlers
  if (!window.mouseOver) {
    window.mouseOver = (event) => {
      // Add your mouseover logic here if needed
    };
  }

  if (!window.mouseOut) {
    window.mouseOut = (event) => {
      // Add your mouseout logic here if needed
    };
  }

  if (!window.mouseClick) {
    window.mouseClick = (event) => {
      window.handleClick(event);
    };
  }

  // Click handling logic
  if (!window.handleClick) {
    window.handleClick = (event) => {
      const questionType = window.getType(event);
      if (questionType === "ABC") {
        window.abcType(event);
      } else {
        window.chooseType(event);
      }
    };
  }

  if (!window.getType) {
    window.getType = (event) => {
      const selectedElement = event.target;
      event.target.style.border = "";
      if (selectedElement) {
        const question = selectedElement.innerText.trim();
        window.question = question;
        const parentFormulation = selectedElement.closest(".formulation");
        const answer = parentFormulation?.querySelector(".answer");
        if (answer?.tagName === "DIV") return "ABC";
        if (answer?.tagName === "TABLE") return "CHOOSE";
      }
      return "ABC";
    };
  }

  if (!window.abcType) {
    window.abcType = (event) => {
      const parseQuestion = (event) => {
        const selectedElement = event.target;
        let question = "";
        let answers = [];
        if (selectedElement) {
          question = selectedElement.innerText.trim();
          const parentFormulation = selectedElement.closest(".formulation");
          if (parentFormulation) {
            answers = Array.from(parentFormulation.querySelectorAll(".answer")).map((answer) =>
              answer.innerText.trim()
            );
          }
        }
        return { question, answers };
      };
      const data = parseQuestion(event);
      const prompt = `Question: ${data.question}\nAnswers: [${data.answers.join(", ")}]\n\nChoose the correct answer and reply with only the answer.`;
      window.fetchGemini(prompt);
    };
  }

  if (!window.chooseType) {
    window.chooseType = (event) => {
      const parseQuestion = (event) => {
        const selectedElement = event.target;
        let questions = [];
        if (selectedElement) {
          const formulation = selectedElement.closest(".formulation");
          Array.from(formulation.querySelectorAll(".r0, .r1")).forEach((r) => {
            const question = r.querySelector(".text")?.innerText;
            const answers = Array.from(formulation.querySelector(".select")?.children || []).map((answer) =>
              answer.innerText.trim()
            );
            questions.push({ question, answers });
          });
        }
        return questions;
      };
      const data = parseQuestion(event);
      let prompt = "";
      data.forEach((d, index) => {
        prompt += `Question ${index + 1}: ${d.question}\nAnswers: [${d.answers.join(", ")}]\n\n`;
      });
      prompt += "Choose the correct answer for each question and reply in the format:\n1. Answer\n2. Answer\n3. Answer";
      window.fetchGemini(prompt);
    };
  }

  if (!window.fetchGemini) {
    window.fetchGemini = (prompt) => {
      const body = {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7 },
      };
      fetch(GEMINI_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      })
        .then((response) => {
          if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
          return response.json();
        })
        .then((data) => {
          const responseText = data.candidates[0].content.parts[0].text;
          window.showNotification(responseText);
        })
        .catch((error) => {
          console.error("Error fetching response from Gemini:", error);
        });
    };
  }

  // Check if listeners are already registered to avoid duplicates
  if (!window.listenersRegistered) {
    window.listenersRegistered = true;
    window.registerListeners();
  }
})();