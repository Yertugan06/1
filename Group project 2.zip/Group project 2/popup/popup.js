let count = 0;
const maxCount = 1000;

const intervalId = setInterval(() => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      const activeTab = tabs[0];
      const siteURL = activeTab.url;

      document.getElementById("blocking-domain").textContent = siteURL;
      count++;

      // Stop the interval after 1000 iterations
      if (count >= maxCount) {
        clearInterval(intervalId);
      }
    }
  });
}, 1000); // Check every 1000 milliseconds (1 second)